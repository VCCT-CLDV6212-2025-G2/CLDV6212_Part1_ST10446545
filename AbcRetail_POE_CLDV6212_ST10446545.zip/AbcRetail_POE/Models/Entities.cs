﻿//**************************************************************************************************
//CLDV6212_POE_ST10446545_ST10446545@vcconnect.edu.za
//**************************************************************************************************

using Azure;
using Azure.Data.Tables;

namespace AbcRetail.Models
{
    public class BaseEntity : ITableEntity
    {
        public string PartitionKey { get; set; } = "default";
        public string RowKey { get; set; } = Guid.NewGuid().ToString();
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
    }

    public class CustomerEntity : BaseEntity
    {
        public string FirstName { get; set; } = "";
        public string LastName { get; set; } = "";
        public string Email { get; set; } = "";
    }

    public class ProductEntity : BaseEntity
    {
        public string Name { get; set; } = "";
        public string Description { get; set; } = "";
        public double Price { get; set; }
        public string ImageBlobName { get; set; } = ""; 
    }

    public class OrderEntity : BaseEntity
    {
        public string CustomerId { get; set; } = "";
        public string ProductId { get; set; } = "";
        public int Quantity { get; set; }
        public decimal LineTotal { get; set; }
    }
}
//------------------------------------------------------------------------------------ End Of File ------------------------------------------------------------------------------------------