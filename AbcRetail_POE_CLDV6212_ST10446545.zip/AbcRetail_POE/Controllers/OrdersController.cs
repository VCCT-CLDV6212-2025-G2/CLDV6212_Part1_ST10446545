﻿//**************************************************************************************************
//CLDV6212_POE_ST10446545_ST10446545@vcconnect.edu.za
//**************************************************************************************************

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Text;
using System.Text.Json;
using AbcRetail.Models;
using AbcRetail.Services;

namespace AbcRetail.Controllers
{
    public class OrdersController : Controller
    {
        private readonly TableStore<OrderEntity> _orders;
        private readonly TableStore<CustomerEntity> _customers;
        private readonly TableStore<ProductEntity> _products;
        private readonly QueueBus _queue;

        public OrdersController(
            TableStore<OrderEntity> orders,
            TableStore<CustomerEntity> customers,
            TableStore<ProductEntity> products,
            QueueBus queue)
        {
            _orders = orders;
            _customers = customers;
            _products = products;
            _queue = queue;
        }

        // GET /Orders
        public IActionResult Index()
        {
            var list = _orders.Query().ToList();
            return View(list);
        }

        // GET /Orders/Create
        public IActionResult Create()
        {
            var custs = _customers.Query().ToList();
            var prods = _products.Query().ToList();

            ViewBag.Customers = new SelectList(
                custs, nameof(CustomerEntity.RowKey),
                nameof(CustomerEntity.Email));      // show Email as label

            ViewBag.Products = new SelectList(
                prods, nameof(ProductEntity.RowKey),
                nameof(ProductEntity.Name));        // show Name as label

            return View(new OrderEntity { Quantity = 1 });
        }

        // POST /Orders/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(OrderEntity o)
        {
            if (!ModelState.IsValid) return View(o);

            o.PartitionKey = "orders";

            // Look up product price and compute total
            var product = _products.Query($"RowKey eq '{o.ProductId}'").FirstOrDefault();
            var price = product?.Price ?? 0.0;
            o.LineTotal = (decimal)(price * o.Quantity);   // store as decimal in OrderEntity

            await _orders.AddAsync(o);

            // Send queue message 
            var payload = new
            {
                orderId = o.RowKey,
                customerId = o.CustomerId,
                productId = o.ProductId,
                quantity = o.Quantity,
                total = o.LineTotal,
                createdUtc = DateTime.UtcNow
            };
            var json = JsonSerializer.Serialize(payload);
            var base64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
            await _queue.SendBase64Async(base64);

            TempData["Msg"] = "Order created and queued.";
            return RedirectToAction(nameof(Index));
        }
    }
}
//------------------------------------------------------------------------------------ End Of File ------------------------------------------------------------------------------------------