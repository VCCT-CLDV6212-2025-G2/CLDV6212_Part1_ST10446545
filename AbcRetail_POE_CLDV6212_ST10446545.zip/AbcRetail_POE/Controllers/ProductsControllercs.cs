﻿//**************************************************************************************************
//CLDV6212_POE_ST10446545_ST10446545@vcconnect.edu.za
//**************************************************************************************************

using Microsoft.AspNetCore.Mvc;
using AbcRetail.Models;
using AbcRetail.Services;

namespace AbcRetail.Controllers
{
    public class ProductsController : Controller
    {
        private readonly TableStore<ProductEntity> _store;
        private readonly BlobStore _blob;

        public ProductsController(TableStore<ProductEntity> store, BlobStore blob)
        {
            _store = store;
            _blob = blob;
        }

        // GET /Products
        public IActionResult Index()
        {
            var list = _store.Query().ToList();
            // helper to turn blob name into a URL
            ViewBag.Url = (Func<string, Uri>)(name => string.IsNullOrWhiteSpace(name)
                ? new Uri("about:blank")
                : _blob.GetUri(name));
            return View(list);
        }

        // GET /Products/Create
        public IActionResult Create() => View();

        // POST /Products/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ProductEntity p, IFormFile? image)
        {
            if (!ModelState.IsValid) return View(p);

            p.PartitionKey = "products";

            if (image is { Length: > 0 })
            {
                var blobName = $"{Guid.NewGuid()}-{Path.GetFileName(image.FileName)}";
                using var s = image.OpenReadStream();
                p.ImageBlobName = await _blob.UploadAsync(blobName, s);
            }

            await _store.AddAsync(p);
            TempData["Msg"] = "Product saved and image (if provided) uploaded to Blob Storage.";
            return RedirectToAction(nameof(Index));
        }
        //----------------------------------------------------------------------------------------------------------------------------------------------------------------
        // GET: /Products/Edit/{id}
        public async Task<IActionResult> Edit(string id)
        {
            var p = await _store.GetAsync("products", id);
            if (p is null) return NotFound();
            return View(p);
        }

        // POST: /Products/Edit/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, ProductEntity p, IFormFile? image)
        {
            if (id != p.RowKey) return BadRequest();
            if (!ModelState.IsValid) return View(p);

            p.PartitionKey = "products";

            // optional: replace image if a new one is uploaded
            if (image is { Length: > 0 })
            {
                var blobName = $"{Guid.NewGuid()}-{Path.GetFileName(image.FileName)}";
                using var s = image.OpenReadStream();
                p.ImageBlobName = await _blob.UploadAsync(blobName, s);
            }

            await _store.UpdateAsync(p);
            TempData["Msg"] = "Product updated.";
            return RedirectToAction(nameof(Index));
        }
        //----------------------------------------------------------------------------------------------------------------------------------------------------------------
        // GET: /Products/Delete/{id}
        public async Task<IActionResult> Delete(string id)
        {
            var p = await _store.GetAsync("products", id);
            if (p is null) return NotFound();
            return View(p);
        }

        // POST: /Products/Delete/{id}
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            await _store.DeleteAsync("products", id);
            TempData["Msg"] = "Product deleted.";
            return RedirectToAction(nameof(Index));
        }
    }
}
//------------------------------------------------------------------------------------ End Of File ------------------------------------------------------------------------------------------