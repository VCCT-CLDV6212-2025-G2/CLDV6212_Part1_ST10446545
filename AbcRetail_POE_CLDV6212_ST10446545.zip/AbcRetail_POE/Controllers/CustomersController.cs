﻿//**************************************************************************************************
//CLDV6212_POE_ST10446545_ST10446545@vcconnect.edu.za
//**************************************************************************************************

using Microsoft.AspNetCore.Mvc;
using AbcRetail.Models;
using AbcRetail.Services;

namespace AbcRetail.Controllers
{
    public class CustomersController : Controller
    {
        private readonly TableStore<CustomerEntity> _store;
        public CustomersController(TableStore<CustomerEntity> store) => _store = store;

        // GET: /Customers
        public IActionResult Index()
        {
            var list = _store.Query().ToList(); // pulls from Azure Table "Customers"
            return View(list);
        }

        // GET: /Customers/Create
        public IActionResult Create() => View();

        // POST: /Customers/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CustomerEntity c)
        {
            if (!ModelState.IsValid) return View(c);
            c.PartitionKey = "customers"; // any constant partition works
            await _store.AddAsync(c);
            TempData["Msg"] = "Customer saved to Azure Table Storage.";
            return RedirectToAction(nameof(Index));
        }
        //----------------------------------------------------------------------------------------------------------------------------------------------------------------
        // GET: /Customers/Edit/{id}
        public async Task<IActionResult> Edit(string id)
        {
            var c = await _store.GetAsync("customers", id);
            if (c is null) return NotFound();
            return View(c);
        }

        // POST: /Customers/Edit/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, CustomerEntity c)
        {
            if (id != c.RowKey) return BadRequest();
            if (!ModelState.IsValid) return View(c);

            c.PartitionKey = "customers";
            await _store.UpdateAsync(c);
            TempData["Msg"] = "Customer updated.";
            return RedirectToAction(nameof(Index));
        }
        //----------------------------------------------------------------------------------------------------------------------------------------------------------------
        // GET: /Customers/Delete/{id}
        public async Task<IActionResult> Delete(string id)
        {
            var c = await _store.GetAsync("customers", id);
            if (c is null) return NotFound();
            return View(c);
        }

        // POST: /Customers/Delete/{id}
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            await _store.DeleteAsync("customers", id);
            TempData["Msg"] = "Customer deleted.";
            return RedirectToAction(nameof(Index));
        }
    }
}
//------------------------------------------------------------------------------------ End Of File ------------------------------------------------------------------------------------------