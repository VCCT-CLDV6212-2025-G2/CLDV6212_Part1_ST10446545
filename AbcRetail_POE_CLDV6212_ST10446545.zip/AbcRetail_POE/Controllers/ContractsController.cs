﻿//**************************************************************************************************
//CLDV6212_POE_ST10446545_ST10446545@vcconnect.edu.za
//**************************************************************************************************

using Microsoft.AspNetCore.Mvc;
using AbcRetail.Services;
using System.Text;          
using System.IO;

namespace AbcRetail.Controllers
{
    public class ContractsController : Controller
    {
        private readonly FileShareStore _files;

        public ContractsController(FileShareStore files) => _files = files;

        // GET /Contracts
        public IActionResult Index() => View();

        // GET /Contracts/Upload
        public IActionResult Upload() => View();

        // POST /Contracts/Upload
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Upload(IFormFile? doc)
        {
            if (doc is null || doc.Length == 0)
            {
                TempData["Msg"] = "Please choose a file.";
                return RedirectToAction(nameof(Index));
            }

            var safeName = $"{Guid.NewGuid()}-{Path.GetFileName(doc.FileName)}";
            using var s = doc.OpenReadStream();
            await _files.UploadAsync(safeName, s);

            TempData["Msg"] = $"Uploaded '{doc.FileName}' to Azure Files.";
            return RedirectToAction(nameof(Index));


        }
    }
}
//------------------------------------------------------------------------------------ End Of File ------------------------------------------------------------------------------------------