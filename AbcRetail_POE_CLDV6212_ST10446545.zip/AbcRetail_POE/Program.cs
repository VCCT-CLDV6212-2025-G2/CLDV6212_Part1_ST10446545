using AbcRetail.Models;
using AbcRetail.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Table stores
builder.Services.AddSingleton<TableStore<CustomerEntity>>(sp =>
    new TableStore<CustomerEntity>(sp.GetRequiredService<IConfiguration>(),
        sp.GetRequiredService<IConfiguration>()["AzureStorage:Tables:Customers"]!));

builder.Services.AddSingleton<TableStore<ProductEntity>>(sp =>
    new TableStore<ProductEntity>(sp.GetRequiredService<IConfiguration>(),
        sp.GetRequiredService<IConfiguration>()["AzureStorage:Tables:Products"]!));

builder.Services.AddSingleton<TableStore<OrderEntity>>(sp =>
    new TableStore<OrderEntity>(sp.GetRequiredService<IConfiguration>(),
        sp.GetRequiredService<IConfiguration>()["AzureStorage:Tables:Orders"]!));

// Other stores
builder.Services.AddSingleton<BlobStore>();
builder.Services.AddSingleton<QueueBus>();
builder.Services.AddSingleton<FileShareStore>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
