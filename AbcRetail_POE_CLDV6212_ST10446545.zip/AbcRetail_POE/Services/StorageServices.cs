﻿//**************************************************************************************************
//CLDV6212_POE_ST10446545_ST10446545@vcconnect.edu.za
//**************************************************************************************************

using Azure.Data.Tables;
using Azure.Storage.Blobs;
using Azure.Storage.Queues;
using Azure.Storage.Files.Shares;
using AbcRetail.Models;
using Azure;

namespace AbcRetail.Services
{
    // Generic Table wrapper
    public class TableStore<T> where T : class, ITableEntity, new()
    {
        private readonly TableClient _table;
        public TableStore(IConfiguration cfg, string tableName)
        {
            var cs = cfg["AzureStorage:ConnectionString"];
            _table = new TableClient(cs, tableName);
            _table.CreateIfNotExists();
        }
        public async Task AddAsync(T entity) => await _table.AddEntityAsync(entity);
        public async Task UpdateAsync(T entity) => await _table.UpdateEntityAsync(entity, entity.ETag, TableUpdateMode.Replace);
        public async Task DeleteAsync(string pk, string rk) => await _table.DeleteEntityAsync(pk, rk);
        public Pageable<T> Query(string? filter = null) => _table.Query<T>(filter);
        public async Task<T?> GetAsync(string pk, string rk) => (await _table.GetEntityAsync<T>(pk, rk)).Value;
    }

    // Blob wrapper for product images
    public class BlobStore
    {
        private readonly BlobContainerClient _container;
        public BlobStore(IConfiguration cfg)
        {
            _container = new BlobContainerClient(
                cfg["AzureStorage:ConnectionString"],
                cfg["AzureStorage:Blob:Container"]);
            _container.CreateIfNotExists();
        }

        public async Task<string> UploadAsync(string fileName, Stream content)
        {
            var blob = _container.GetBlobClient(fileName);
            await blob.UploadAsync(content, overwrite: true);
            return blob.Name; // store name in Table
        }

        public Uri GetUri(string blobName) => _container.GetBlobClient(blobName).Uri;
    }

    // Queue wrapper for “new order” messages
    public class QueueBus
    {
        private readonly QueueClient _queue;
        public QueueBus(IConfiguration cfg)
        {
            _queue = new QueueClient(
                cfg["AzureStorage:ConnectionString"],
                cfg["AzureStorage:Queue:Name"]);
            _queue.CreateIfNotExists();
        }

        public async Task SendBase64Async(string base64) => await _queue.SendMessageAsync(base64);
    }

    // Azure Files wrapper for contracts
    public class FileShareStore
    {
        private readonly ShareClient _share;
        public FileShareStore(IConfiguration cfg)
        {
            _share = new ShareClient(
                cfg["AzureStorage:ConnectionString"],
                cfg["AzureStorage:FileShare:Name"]);
            _share.CreateIfNotExists();
        }

        public async Task UploadAsync(string fileName, Stream stream)
        {
            //Make sure the Share itself exists
            await _share.CreateIfNotExistsAsync();

            //Get the root directory and the file client
            ShareDirectoryClient root = _share.GetRootDirectoryClient(); 
            ShareFileClient file = root.GetFileClient(fileName);

            //Rewind stream and create the file with the exact size
            if (stream.CanSeek) stream.Position = 0;
            await file.CreateAsync(stream.Length);

            //Upload the bytes using UploadRange (Files expects this)
            await file.UploadRangeAsync(new HttpRange(0, stream.Length), stream);
        }
    }
}
//------------------------------------------------------------------------------------ End Of File ------------------------------------------------------------------------------------------

//References
// https://chatgpt.com/share/68b0b6f7-91e8-8008-9c8d-b164767593c9, Ln80, struggled with the Azure Files Async method, asked chatgpt to guide me back on the right path